from django.apps import AppConfig


class ForensicevidenceappConfig(AppConfig):
    name = 'ForensicEvidenceApp'
