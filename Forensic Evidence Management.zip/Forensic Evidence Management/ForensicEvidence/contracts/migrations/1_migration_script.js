const exports = artifacts.require('ForensicEvidenceContract')
module.exports =  function (delpoyer){
    delpoyer.deploy(exports)
}